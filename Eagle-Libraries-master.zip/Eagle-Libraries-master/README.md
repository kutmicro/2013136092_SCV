# Eagle-Libraries

EAGLE CAD library collection of the following manufacturers

muRata              : capacitors, buzzers
Laird Technologies  : Bluetooth modules
MAXIM               : IC, semiconductors
Microchip           : IC, semiconductor devices
ROHM Semiconductor  : resistors, tantalum capacitors
